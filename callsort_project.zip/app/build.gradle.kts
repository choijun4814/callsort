import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val buildStamp = ZonedDateTime.now(ZoneId.of("Asia/Seoul"))
    .format(DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm:ss"))

android {
    buildFeatures { buildConfig = true }
    namespace = "com.callsort"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.callsort"
        minSdk = 30
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String", "BUILD_DATE", "\"$buildStamp\"")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
