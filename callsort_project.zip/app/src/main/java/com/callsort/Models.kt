package com.callsort

import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Rec(
    val uri: Uri, val name: String, val path: String, val size: Long,
    val durMs: Long, val date: Long, val group: String, val call: Boolean
)

sealed class Row {
    class Group(val group: String, val items: List<Rec>) : Row()
    class File(val rec: Rec) : Row()
}

object Util {
    val KEYWORDS = listOf("통화", "녹음", "전화", "call", "record", "voice")

    private val PREFIX = Regex(
        "^(통화\\s*녹음|call\\s*recording|call\\s*record|call|녹음|recording|voice\\s*recorder|voice)[\\s_\\-]*",
        RegexOption.IGNORE_CASE
    )
    private val TAILS = listOf(
        Regex("[\\s_\\-]*\\(\\d+\\)$"),
        Regex("[\\s_\\-]*\\d{4}[-.]\\d{2}[-.]\\d{2}.*$"),
        Regex("[\\s_\\-]+\\d{8}[\\s_\\-]+\\d{4,6}$"),
        Regex("[\\s_\\-]+\\d{6}[\\s_\\-]+\\d{4,6}$"),
        Regex("[\\s_\\-]+\\d{14}$"),
        Regex("[\\s_\\-]+\\d{6,8}$")
    )
    private val BAD_CHARS = Regex("""[\\/:*?"<>|]""")

    // 파일명에서 접두어(통화 녹음 등)와 날짜/시간 꼬리를 떼어 상대방 이름/번호만 남긴다.
    fun groupKey(name: String): String {
        var s = name.substringBeforeLast('.', name).trim()
        s = PREFIX.replace(s, "")
        var changed = true
        while (changed) {
            changed = false
            for (r in TAILS) {
                val n = r.replace(s, "")
                if (n != s) { s = n; changed = true }
            }
        }
        s = s.trim(' ', '_', '-').replace(Regex("\\s+"), " ")
        return if (s.isEmpty()) "(이름 없음)" else s
    }

    fun safe(s: String, def: String): String {
        val t = s.replace(BAD_CHARS, "_").trim().trim('.').take(40)
        return if (t.isEmpty()) def else t
    }

    fun fmtBytes(b: Long): String = when {
        b >= 1073741824L -> String.format(Locale.US, "%.1fGB", b / 1073741824.0)
        b >= 1048576L -> String.format(Locale.US, "%.1fMB", b / 1048576.0)
        b >= 1024L -> "${b / 1024}KB"
        else -> "${b}B"
    }

    fun fmtDur(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    fun fmtDate(sec: Long): String =
        SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA).format(Date(sec * 1000))
}
