package com.callsort

import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Rec(
    val uri: Uri, val name: String, val path: String, val size: Long,
    val durMs: Long, val date: Long, val group: String, val call: Boolean,
    val sorted: Boolean = false
)

sealed class Row {
    class Group(val group: String, val items: List<Rec>) : Row()
    class File(val rec: Rec) : Row()
}

object Util {
    val KEYWORDS = listOf("통화", "녹음", "전화", "call", "record", "voice")

    private val PREFIX = Regex(
        "^(통화\\s*녹음|call\\s*recording|call\\s*record|call|녹음|recording|voice\\s*recorder|voice)[\\s_\\-]*",
        RegexOption.IGNORE_CASE
    )
    private val TAILS = listOf(
        Regex("[\\s_\\-]*\\(\\d+\\)$"),
        Regex("[\\s_\\-]*\\d{4}[-.]\\d{2}[-.]\\d{2}.*$"),
        Regex("[\\s_\\-]+\\d{8}[\\s_\\-]+\\d{4,6}$"),
        Regex("[\\s_\\-]+\\d{6}[\\s_\\-]+\\d{4,6}$"),
        Regex("[\\s_\\-]+\\d{14}$"),
        Regex("[\\s_\\-]+\\d{6,8}$")
    )
    private val BAD_CHARS = Regex("""[\\/:*?"<>|]""")

    // 파일명에서 접두어(통화 녹음 등)와 날짜/시간 꼬리를 떼어 상대방 이름/번호만 남긴다.
    fun groupKey(name: String): String {
        var s = name.substringBeforeLast('.', name).trim()
        s = PREFIX.replace(s, "")
        var changed = true
        while (changed) {
            changed = false
            for (r in TAILS) {
                val n = r.replace(s, "")
                if (n != s) { s = n; changed = true }
            }
        }
        s = s.trim(' ', '_', '-').replace(Regex("\\s+"), " ")
        return if (s.isEmpty()) "(이름 없음)" else s
    }

    // 안드로이드(MediaStore)가 오디오 파일에 허용하는 최상위 폴더. Recordings는 Android 12(API 31) 이상.
    private val ALLOWED = mapOf(
        "music" to "Music", "recordings" to "Recordings", "podcasts" to "Podcasts",
        "audiobooks" to "Audiobooks", "alarms" to "Alarms",
        "notifications" to "Notifications", "ringtones" to "Ringtones"
    )
    fun topFolders(sdk: Int): List<String> =
        ALLOWED.values.filter { it != "Recordings" || sdk >= 31 }

    private val BLOCKED = setOf("download", "downloads", "documents", "dcim", "pictures", "movies", "android")

    // 사용자가 입력한 저장 경로를 정리. 최상위 폴더를 생략하면 Music 아래로 둔다.
    // 안드로이드가 오디오에 허용하지 않는 최상위 폴더면 null.
    fun normPath(input: String, def: String, sdk: Int): String? {
        val segs = input.split('/', '\\').map { safe(it, "") }.filter { it.isNotEmpty() }.toMutableList()
        if (segs.isEmpty()) return def
        val top = segs[0].lowercase(Locale.ROOT)
        if (top in BLOCKED) return null
        val canon = ALLOWED[top]
        if (canon == null) segs.add(0, "Music") else segs[0] = canon
        if (segs[0] == "Recordings" && sdk < 31) return null
        return segs.joinToString("/")
    }

    // 저장 경로(bases) 아래에 있거나, Music 아래 마지막 폴더가 이름 그룹과 같으면 분류 완료로 본다.
    fun isSorted(path: String, group: String, bases: Set<String>): Boolean {
        val parts = path.trim('/').split('/').filter { it.isNotEmpty() }
        val full = parts.joinToString("/")
        for (b in bases) {
            val n = b.split('/').filter { it.isNotEmpty() }.size
            if (parts.size > n && (full + "/").startsWith("$b/")) return true
        }
        if (parts.size < 3) return false
        if (!parts[0].equals("Music", ignoreCase = true)) return false
        return parts.last() == safe(group, "기타")
    }

    fun safe(s: String, def: String): String {
        val t = s.replace(BAD_CHARS, "_").trim().trim('.').take(40)
        return if (t.isEmpty()) def else t
    }

    fun fmtBytes(b: Long): String = when {
        b >= 1073741824L -> String.format(Locale.US, "%.1fGB", b / 1073741824.0)
        b >= 1048576L -> String.format(Locale.US, "%.1fMB", b / 1048576.0)
        b >= 1024L -> "${b / 1024}KB"
        else -> "${b}B"
    }

    fun fmtDur(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    fun fmtDate(sec: Long): String =
        SimpleDateFormat("yyyy.MM.dd HH:mm", Locale.KOREA).format(Date(sec * 1000))
}
