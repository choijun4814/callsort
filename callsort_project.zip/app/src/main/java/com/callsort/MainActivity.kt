package com.callsort

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        const val RC_PERM = 1
        const val RC_WRITE = 2
        const val RC_TRASH = 3
        const val BATCH = 1000
        const val DEFAULT_BASE = "Music/통화녹음분리"
        const val PATH_LABEL = "저장 경로 (예: Music/통화녹음분리)"
        const val PATH_HINT = "안드로이드 제한으로 Music, Recordings(안드로이드 12 이상), Podcasts, Audiobooks 등 오디오 폴더 아래로만 이동할 수 있어요. 맨 앞 폴더를 생략하면 Music 아래로 들어갑니다."
    }

    private val ui by lazy { Ui(this) }

    private var recs: List<Rec> = emptyList()
    private val rows = ArrayList<Row>()
    private val selected = HashSet<Uri>()
    private var callOnly = true
    private var hideSorted = true
    private var query = ""
    private var openGroup: String? = null
    private var selMode = false
    private val selGroups = HashSet<String>()
    private var pendingTarget = ""

    private val queue = ArrayDeque<List<Rec>>()
    private var pendingAction = 0
    private var pendingBase = ""
    private var okCount = 0
    private var failCount = 0

    private lateinit var listView: ListView
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var searchBox: EditText
    private lateinit var onlyBox: CheckBox
    private lateinit var sortedBox: CheckBox
    private lateinit var barGroup: LinearLayout
    private lateinit var barDetail: LinearLayout
    private lateinit var barGroupSel: LinearLayout
    private lateinit var bottomGroupSel: LinearLayout
    private lateinit var btnSelMode: Button
    private lateinit var btnGMove: Button
    private lateinit var btnGTrash: Button
    private lateinit var bottomGroup: LinearLayout
    private lateinit var bottomDetail: LinearLayout
    private lateinit var btnMove: Button
    private lateinit var btnTrash: Button
    private lateinit var btnPlay: Button

    private val rowAdapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(position: Int) = if (rows[position] is Row.Group) 0 else 1
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View =
            when (val r = rows[position]) {
                is Row.Group -> ui.groupView(r, selMode, r.group in selGroups)
                is Row.File -> ui.fileView(r.rec, selected)
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(10))
        }
        root.addView(ui.txt("통화녹음 정리", 24f, INK, true))
        root.addView(ui.txt("v2.5 · 빌드 ${BuildConfig.BUILD_DATE}", 12f, MUTED))

        barGroup = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, ui.dp(10), 0, ui.dp(4))
        }
        barGroup.addView(ui.btn("새로 검색", TEAL) { checkPermAndScan() }, ui.weight())
        btnSelMode = ui.btn("이름 여러 개 선택", SLATE) { toggleSelMode() }
        barGroup.addView(btnSelMode, ui.weight())
        root.addView(barGroup)

        barGroupSel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, ui.dp(4))
        }
        barGroupSel.addView(ui.btn("N개 이하 선택", SLATE) { askSelectByCount() }, ui.weight())
        barGroupSel.addView(ui.btn("전체 선택", SLATE) { selectAllGroups(true) }, ui.weight())
        barGroupSel.addView(ui.btn("전체 해제", SLATE) { selectAllGroups(false) }, ui.weight())
        root.addView(barGroupSel)

        barDetail = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, ui.dp(10), 0, ui.dp(4))
        }
        barDetail.addView(ui.btn("← 이름 목록", SLATE) { goBack() }, ui.weight())
        barDetail.addView(ui.btn("전체 선택", SLATE) { selectAll(true) }, ui.weight())
        barDetail.addView(ui.btn("전체 해제", SLATE) { selectAll(false) }, ui.weight())
        root.addView(barDetail)

        searchBox = EditText(this).apply {
            hint = "이름·파일명·폴더 검색"
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; rebuild() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        root.addView(searchBox)

        onlyBox = CheckBox(this).apply {
            text = "통화 녹음 후보만 보기 (이름/폴더에 통화·녹음 등 포함)"
            isChecked = true
            textSize = 13f
            setOnCheckedChangeListener { _, v -> callOnly = v; rebuild() }
        }
        root.addView(onlyBox)

        sortedBox = CheckBox(this).apply {
            text = "이미 분류된 파일 숨기기 (저장 경로 안의 파일)"
            isChecked = true
            textSize = 13f
            setOnCheckedChangeListener { _, v -> hideSorted = v; rebuild() }
        }
        root.addView(sortedBox)

        status = ui.txt("", 13f, MUTED)
        root.addView(status)

        listView = ListView(this).apply {
            adapter = rowAdapter
            divider = null
            setOnItemClickListener { _, _, pos, _ -> onRowClick(pos) }
        }
        root.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        info = ui.txt("", 13f, INK, true)
        info.setPadding(0, ui.dp(8), 0, ui.dp(4))
        root.addView(info)

        bottomGroup = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottomGroup.addView(ui.btn("이름별 자동 분류 (전체)", TEAL) { startAutoSort() }, ui.weight())
        root.addView(bottomGroup)

        bottomGroupSel = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnGMove = ui.btn("선택한 이름 이동", TEAL) { startMoveGroups() }
        btnGTrash = ui.btn("선택한 이름 휴지통", DANGER) { startTrashGroups() }
        bottomGroupSel.addView(btnGMove, ui.weight())
        bottomGroupSel.addView(btnGTrash, ui.weight())
        root.addView(bottomGroupSel)

        bottomDetail = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnPlay = ui.btn("선택 파일 재생", SLATE) { playSelected() }
        btnMove = ui.btn("이 이름 폴더로 이동", TEAL) { startMoveSelected() }
        btnTrash = ui.btn("휴지통으로", DANGER) { startTrash() }
        bottomDetail.addView(btnPlay, ui.weight())
        bottomDetail.addView(btnMove, ui.weight())
        bottomDetail.addView(btnTrash, ui.weight())
        root.addView(bottomDetail)

        setContentView(root)
        applyMode()
        updateBar()
        checkPermAndScan()
    }

    private fun applyMode() {
        val detail = openGroup != null
        barGroup.visibility = if (detail) View.GONE else View.VISIBLE
        barGroupSel.visibility = if (!detail && selMode) View.VISIBLE else View.GONE
        bottomGroupSel.visibility = if (!detail && selMode) View.VISIBLE else View.GONE
        btnSelMode.text = if (selMode) "선택 종료" else "이름 여러 개 선택"
        barDetail.visibility = if (detail) View.VISIBLE else View.GONE
        searchBox.visibility = View.VISIBLE
        onlyBox.visibility = if (detail) View.GONE else View.VISIBLE
        sortedBox.visibility = if (detail) View.GONE else View.VISIBLE
        bottomGroup.visibility = if (detail || selMode) View.GONE else View.VISIBLE
        bottomDetail.visibility = if (detail) View.VISIBLE else View.GONE
        info.visibility = if (detail || selMode) View.VISIBLE else View.GONE
    }

    private fun goBack() {
        openGroup = null
        selected.clear()
        applyMode()
        rebuild()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (openGroup != null) goBack()
        else if (selMode) toggleSelMode()
        else super.onBackPressed()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
        searchBox.clearFocus()
    }

    private fun perm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun checkPermAndScan() {
        if (checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED) scan()
        else requestPermissions(arrayOf(perm()), RC_PERM)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == RC_PERM && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) {
            scan()
        } else {
            status.text = "오디오 파일 접근 권한이 필요합니다. 새로 검색을 눌러 허용해 주세요."
        }
    }

    private fun scan() {
        status.text = "검색 중..."
        val bases = knownBases()
        thread {
            val out = ArrayList<Rec>()
            try {
                val proj = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.RELATIVE_PATH,
                    MediaStore.Audio.Media.SIZE,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.DATE_MODIFIED
                )
                val args = Bundle().apply {
                    putString(
                        android.content.ContentResolver.QUERY_ARG_SQL_SORT_ORDER,
                        MediaStore.Audio.Media.DATE_MODIFIED + " DESC"
                    )
                    putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_EXCLUDE)
                    putInt(MediaStore.QUERY_ARG_MATCH_PENDING, MediaStore.MATCH_EXCLUDE)
                }
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, args, null
                )?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                    val iPath = c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)
                    val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                    val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val iDate = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                    while (c.moveToNext()) {
                        val name = c.getString(iName) ?: continue
                        val path = c.getString(iPath) ?: ""
                        val hay = (name + " " + path).lowercase(Locale.ROOT)
                        val grp = Util.groupKey(name)
                        out.add(
                            Rec(
                                uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(iId)),
                                name = name, path = path,
                                size = c.getLong(iSize), durMs = c.getLong(iDur), date = c.getLong(iDate),
                                group = grp,
                                call = Util.KEYWORDS.any { hay.contains(it) },
                                sorted = Util.isSorted(path, grp, bases)
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("검색 오류: ${e.message}") }
            }
            runOnUiThread { recs = out; rebuild() }
        }
    }

    private fun visibleRecs() = recs.filter { (!callOnly || it.call) && (!hideSorted || !it.sorted) }

    private fun rebuild() {
        val vis = visibleRecs()
        rows.clear()
        val g = openGroup
        if (g == null) {
            val q = query.trim().lowercase(Locale.ROOT)
            val groups = vis.groupBy { it.group }.entries
                .filter { q.isEmpty() || it.key.lowercase(Locale.ROOT).contains(q) }
                .sortedWith(compareByDescending<Map.Entry<String, List<Rec>>> { it.value.size }.thenBy { it.key })
            for ((name, items) in groups) rows.add(Row.Group(name, items))
            selGroups.retainAll(groups.map { it.key }.toSet())
            val hidden = if (hideSorted) recs.count { it.sorted } else 0
            status.text = "${groups.size}개 이름 · ${groups.sumOf { it.value.size }}개 파일 (전체 오디오 ${recs.size}개" +
                (if (hidden > 0) ", 분류 완료 ${hidden}개 숨김" else "") + ")"
        } else {
            val q = query.trim().lowercase(Locale.ROOT)
            val items = vis.filter {
                it.group == g && (q.isEmpty() || it.name.lowercase(Locale.ROOT).contains(q) ||
                    it.path.lowercase(Locale.ROOT).contains(q) || it.group.lowercase(Locale.ROOT).contains(q))
            }.sortedByDescending { it.date }
            if (vis.none { it.group == g }) {
                openGroup = null
                applyMode()
                rebuild()
                return
            }
            items.forEach { rows.add(Row.File(it)) }
            selected.retainAll(items.map { it.uri }.toSet())
            status.text = "$g · ${items.size}개 파일 · 전체 ${vis.size}개 중 (눌러서 선택)"
        }
        rowAdapter.notifyDataSetChanged()
        updateBar()
    }

    private fun onRowClick(pos: Int) {
        when (val r = rows[pos]) {
            is Row.Group -> if (selMode) {
                if (!selGroups.remove(r.group)) selGroups.add(r.group)
                rowAdapter.notifyDataSetChanged()
                updateBar()
            } else {
                hideKeyboard()
                openGroup = r.group
                selected.clear()
                applyMode()
                rebuild()
                listView.setSelection(0)
            }
            is Row.File -> {
                if (!selected.remove(r.rec.uri)) selected.add(r.rec.uri)
                rowAdapter.notifyDataSetChanged()
                updateBar()
            }
        }
    }

    private fun selectAll(on: Boolean) {
        selected.clear()
        if (on) rows.forEach { if (it is Row.File) selected.add(it.rec.uri) }
        rowAdapter.notifyDataSetChanged()
        updateBar()
    }

    private fun selectedRecs() = recs.filter { it.uri in selected }

    private fun selectedGroupRecs() = visibleRecs().filter { it.group in selGroups }

    private fun updateBar() {
        if (openGroup == null && selMode) {
            val g = selectedGroupRecs()
            info.text = if (selGroups.isEmpty()) "선택한 이름 없음"
            else "이름 ${selGroups.size}개 · 파일 ${g.size}개 · ${Util.fmtBytes(g.sumOf { it.size })}"
            val on = g.isNotEmpty()
            for (b in listOf(btnGMove, btnGTrash)) { b.isEnabled = on; b.alpha = if (on) 1f else 0.4f }
        }
        val sel = selectedRecs()
        if (openGroup != null) {
            info.text = if (sel.isEmpty()) "선택한 파일 없음" else "선택 ${sel.size}개 · ${Util.fmtBytes(sel.sumOf { it.size })}"
        }
        val on = sel.isNotEmpty()
        for (b in listOf(btnPlay, btnMove, btnTrash)) { b.isEnabled = on; b.alpha = if (on) 1f else 0.4f }
    }

    private fun toggleSelMode() {
        selMode = !selMode
        selGroups.clear()
        applyMode()
        rebuild()
    }

    private fun selectAllGroups(on: Boolean) {
        selGroups.clear()
        if (on) rows.forEach { if (it is Row.Group) selGroups.add(it.group) }
        rowAdapter.notifyDataSetChanged()
        updateBar()
    }

    // 통화 개수가 N개 이하인 이름을 한 번에 선택 (현재 목록에 보이는 이름 기준, 기존 선택에 추가)
    private fun askSelectByCount() {
        val et = EditText(this).apply {
            setText("2"); setSingleLine(); inputType = InputType.TYPE_CLASS_NUMBER
        }
        AlertDialog.Builder(this)
            .setTitle("통화 개수로 선택")
            .setMessage("통화(파일) 개수가 이 숫자 이하인 이름을 모두 선택합니다. 선택 후 아래 버튼으로 한 번에 이동하거나 휴지통으로 보낼 수 있어요.")
            .setView(et)
            .setPositiveButton("선택") { _, _ ->
                val n = et.text.toString().toIntOrNull()
                if (n == null || n < 1) { toast("1 이상의 숫자를 입력해 주세요"); return@setPositiveButton }
                var cnt = 0
                rows.forEach { if (it is Row.Group && it.items.size <= n) { selGroups.add(it.group); cnt++ } }
                toast("${n}개 이하 이름 ${cnt}개를 선택했습니다")
                rowAdapter.notifyDataSetChanged()
                updateBar()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // 선택한 이름들의 파일을 이동. 합칠 이름을 적으면 전부 그 이름 폴더 하나로 합친다.
    private fun startMoveGroups() {
        val sel = selectedGroupRecs()
        if (sel.isEmpty()) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        }
        val etBase = EditText(this).apply { setText(lastBase()); setSingleLine() }
        val etTarget = EditText(this).apply { hint = "예: 홍길동 (비우면 이름별로 각각)"; setSingleLine() }
        box.addView(ui.txt(PATH_LABEL, 12f, MUTED))
        box.addView(etBase)
        box.addView(folderBtn(etBase))
        box.addView(ui.txt("합칠 이름 (같은 사람이면 입력)", 12f, MUTED))
        box.addView(etTarget)
        AlertDialog.Builder(this)
            .setTitle("선택한 이름 이동")
            .setMessage("이름 ${selGroups.size}개, 파일 ${sel.size}개를 <저장 경로>/<이름>/ 으로 이동합니다.\n합칠 이름을 비우면 이름별 폴더로 각각 이동하고, 입력하면 전부 그 이름 폴더 하나로 합칩니다.")
            .setView(box)
            .setPositiveButton("이동") { _, _ ->
                val t = etTarget.text.toString().trim()
                val target = if (t.isEmpty()) "" else Util.safe(t, "기타")
                val base = readPath(etBase.text.toString()) ?: return@setPositiveButton
                startBatches(RC_WRITE, sel, base, target)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun startTrashGroups() {
        val sel = selectedGroupRecs()
        if (sel.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("선택한 이름 휴지통으로")
            .setMessage("이름 ${selGroups.size}개, 파일 ${sel.size}개(${Util.fmtBytes(sel.sumOf { it.size })})를 휴지통으로 보냅니다. 시스템 휴지통에서 약 30일간 복구할 수 있습니다.")
            .setPositiveButton("휴지통으로") { _, _ -> startBatches(RC_TRASH, sel, "") }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun playSelected() {
        val item = selectedRecs().firstOrNull()
        if (item == null) { toast("재생할 파일을 선택해 주세요"); return }
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(item.uri, "audio/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "녹음 파일 재생"))
        } catch (e: Exception) { toast("재생 앱을 찾을 수 없습니다: ${e.message}") }
    }

    // 이 이름에서 선택한 파일만 <저장 경로>/<이름>/ 으로 이동
    private fun startMoveSelected() {
        val sel = selectedRecs()
        if (sel.isEmpty()) return
        val et = EditText(this).apply { setText(lastBase()); setSingleLine() }
        val pbox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
            addView(et)
            addView(folderBtn(et))
        }
        AlertDialog.Builder(this)
            .setTitle("저장 경로")
            .setMessage("$PATH_HINT\n\n<저장 경로>/<이름>/ 으로 선택한 ${sel.size}개 파일을 이동합니다.")
            .setView(pbox)
            .setPositiveButton("이동") { _, _ ->
                val base = readPath(et.text.toString()) ?: return@setPositiveButton
                startBatches(RC_WRITE, sel, base)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // 선택한 파일만 휴지통으로
    private fun startTrash() {
        val sel = selectedRecs()
        if (sel.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("휴지통으로 이동")
            .setMessage("선택한 ${sel.size}개 파일(${Util.fmtBytes(sel.sumOf { it.size })})을 휴지통으로 보냅니다. 시스템 휴지통에서 약 30일간 복구할 수 있습니다.")
            .setPositiveButton("휴지통으로") { _, _ -> startBatches(RC_TRASH, sel, "") }
            .setNegativeButton("취소", null)
            .show()
    }

    // 전체를 이름별 폴더로 자동 분류 (파일이 N개 이상인 이름만)
    private fun startAutoSort() {
        val vis = recs.filter { (!callOnly || it.call) && it.group != "(이름 없음)" && !it.sorted }
        if (vis.isEmpty()) { toast("분류할 파일이 없습니다"); return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        }
        val etBase = EditText(this).apply { setText(lastBase()); setSingleLine() }
        val etMin = EditText(this).apply {
            setText("2"); setSingleLine(); inputType = InputType.TYPE_CLASS_NUMBER
        }
        box.addView(ui.txt(PATH_LABEL, 12f, MUTED))
        box.addView(etBase)
        box.addView(folderBtn(etBase))
        box.addView(ui.txt("파일이 이 개수 이상인 이름만 분류", 12f, MUTED))
        box.addView(etMin)
        AlertDialog.Builder(this)
            .setTitle("이름별 자동 분류")
            .setMessage("<저장 경로>/<이름>/ 으로 이동합니다. 파일이 많으면 확인 창이 여러 번 뜹니다.\n$PATH_HINT")
            .setView(box)
            .setPositiveButton("분류") { _, _ ->
                val min = (etMin.text.toString().toIntOrNull() ?: 2).coerceAtLeast(1)
                val counts = vis.groupingBy { it.group }.eachCount()
                val targets = vis.filter { (counts[it.group] ?: 0) >= min }
                val base = readPath(etBase.text.toString()) ?: return@setPositiveButton
                startBatches(RC_WRITE, targets, base)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun startBatches(action: Int, list: List<Rec>, base: String, target: String = "") {
        if (list.isEmpty()) { toast("대상 파일이 없습니다"); return }
        pendingAction = action
        pendingBase = base
        pendingTarget = target
        if (action == RC_WRITE) saveBase(base)
        okCount = 0
        failCount = 0
        queue.clear()
        list.chunked(BATCH).forEach { queue.addLast(it) }
        processNext()
    }

    private fun processNext() {
        val batch = queue.firstOrNull()
        if (batch == null) { finishAll(); return }
        val uris = batch.map { it.uri }
        val pi = if (pendingAction == RC_WRITE) {
            MediaStore.createWriteRequest(contentResolver, uris)
        } else {
            MediaStore.createTrashRequest(contentResolver, uris, true)
        }
        requestSystem(pendingAction, pi)
    }

    private fun finishAll() {
        if (pendingAction == RC_WRITE) toast("이동 완료 ${okCount}개, 실패 ${failCount}개")
        else toast("휴지통으로 ${okCount}개 이동했습니다")
        selected.clear()
        selGroups.clear()
        scan()
    }

    private fun requestSystem(code: Int, pi: PendingIntent) {
        try {
            startIntentSenderForResult(pi.intentSender, code, null, 0, 0, 0)
        } catch (e: Exception) {
            toast("요청 실패: ${e.message}")
            queue.clear()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != RC_WRITE && requestCode != RC_TRASH) return
        if (resultCode != RESULT_OK) {
            toast("취소되었습니다 (처리된 파일 ${okCount}개)")
            queue.clear()
            selected.clear()
            scan()
            return
        }
        val batch = queue.removeFirstOrNull() ?: return
        if (requestCode == RC_WRITE) {
            moveBatch(batch)
        } else {
            okCount += batch.size
            processNext()
        }
    }

    private fun moveBatch(batch: List<Rec>) {
        val base = pendingBase
        val target = pendingTarget
        thread {
            var ok = 0
            var fail = 0
            for (r in batch) {
                try {
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "$base/${if (target.isEmpty()) Util.safe(r.group, "기타") else target}/")
                    }
                    if (contentResolver.update(r.uri, cv, null, null) > 0) ok++ else fail++
                } catch (e: Exception) {
                    fail++
                }
            }
            runOnUiThread {
                okCount += ok
                failCount += fail
                processNext()
            }
        }
    }

    // ---- 폴더 선택 / 새 폴더 만들기 ----
    private val madeDirs = HashSet<String>()

    private fun folderBtn(target: EditText): Button =
        ui.btn("📁 폴더 선택 / 새 폴더 만들기", SLATE) {
            val start = fixPath(target.text.toString()) ?: "Music"
            pickFolder(start) { target.setText(it) }
        }

    // 기기에 있는 오디오 파일의 경로와, 이번에 새로 만든 폴더를 합쳐 폴더 목록을 만든다.
    private fun allDirs(): Set<String> {
        val out = HashSet<String>()
        val tops = Util.topFolders(Build.VERSION.SDK_INT).toSet()
        fun addWithParents(path: String) {
            val parts = path.trim('/').split('/').filter { it.isNotEmpty() }
            var acc = ""
            for (p in parts) {
                acc = if (acc.isEmpty()) p else "$acc/$p"
                if (parts[0] in tops) out.add(acc)
            }
        }
        recs.forEach { addWithParents(it.path) }
        madeDirs.forEach { addWithParents(it) }
        return out
    }

    private fun pickFolder(start: String, onPick: (String) -> Unit) {
        browse(start, onPick)
    }

    private fun browse(cur: String, onPick: (String) -> Unit) {
        val dirs = allDirs()
        val subs: List<String> = if (cur.isEmpty()) Util.topFolders(Build.VERSION.SDK_INT)
        else dirs.filter { it.substringBeforeLast('/', "") == cur }.sorted()
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (cur.isNotEmpty()) {
            labels.add("✓ 여기에 저장: $cur")
            acts.add { onPick(cur) }
        }
        labels.add("＋ 새 폴더 만들기" + if (cur.isEmpty()) " (Music 아래)" else "")
        acts.add { newFolder(cur.ifEmpty { "Music" }, onPick) }
        if (cur.isNotEmpty()) {
            labels.add("↑ 상위 폴더")
            acts.add { browse(cur.substringBeforeLast('/', ""), onPick) }
        }
        for (d in subs) {
            val full = if (cur.isEmpty()) d else d
            labels.add("📁 " + d.substringAfterLast('/'))
            acts.add { browse(full, onPick) }
        }
        AlertDialog.Builder(this)
            .setTitle(if (cur.isEmpty()) "폴더 선택" else "폴더: $cur")
            .setItems(labels.toTypedArray()) { _, which -> acts[which]() }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun newFolder(parent: String, onPick: (String) -> Unit) {
        val et = EditText(this).apply { hint = "새 폴더 이름"; setSingleLine() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
            addView(et)
        }
        AlertDialog.Builder(this)
            .setTitle("새 폴더 만들기")
            .setMessage("위치: $parent")
            .setView(box)
            .setPositiveButton("만들기") { _, _ ->
                val name = Util.safe(et.text.toString(), "")
                if (name.isEmpty()) { toast("폴더 이름을 입력해 주세요"); browse(parent, onPick); return@setPositiveButton }
                val path = "$parent/$name"
                madeDirs.add(path)
                toast("폴더가 만들어졌어요. 파일을 이동하면 실제로 생성됩니다.")
                browse(path, onPick)
            }
            .setNegativeButton("취소") { _, _ -> browse(parent, onPick) }
            .show()
    }

    // 마지막에 쓴 저장 경로를 기억해서 매번 같은 경로로 이동 (폴더가 계속 늘어나는 것 방지)
    private fun fixPath(b: String): String? = Util.normPath(b, DEFAULT_BASE, Build.VERSION.SDK_INT)

    private fun lastBase(): String {
        val v = getSharedPreferences("callsort", MODE_PRIVATE).getString("base", null) ?: return DEFAULT_BASE
        return fixPath(v) ?: DEFAULT_BASE   // 예전 버전에 저장된 '폴더 이름만' 값도 Music/ 아래로 변환됨
    }

    // 입력한 저장 경로를 검사. 안드로이드가 허용하지 않는 경로면 안내 후 null.
    private fun readPath(input: String): String? {
        val p = fixPath(input)
        if (p == null) toast("이 경로는 쓸 수 없어요. 오디오 파일은 Music, Recordings, Podcasts, Audiobooks, Alarms, Notifications, Ringtones 폴더 아래로만 이동할 수 있습니다.")
        return p
    }

    private fun saveBase(b: String) {
        val sp = getSharedPreferences("callsort", MODE_PRIVATE)
        val set = HashSet(sp.getStringSet("bases", emptySet()) ?: emptySet())
        set.add(b)
        sp.edit().putString("base", b).putStringSet("bases", set).apply()
    }

    private fun knownBases(): Set<String> {
        val sp = getSharedPreferences("callsort", MODE_PRIVATE)
        val saved = (sp.getStringSet("bases", emptySet()) ?: emptySet()).mapNotNull { fixPath(it) }
        return (saved + DEFAULT_BASE + lastBase()).toSet()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
