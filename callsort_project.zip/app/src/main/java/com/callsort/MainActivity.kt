package com.callsort

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        const val RC_PERM = 1
        const val RC_WRITE = 2
        const val RC_TRASH = 3
    }

    private val ui by lazy { Ui(this) }

    private var recs: List<Rec> = emptyList()
    private val rows = ArrayList<Row>()
    private val selected = HashSet<Uri>()
    private var callOnly = true
    private var pendingMove: List<Rec> = emptyList()
    private var pendingBase = ""

    private lateinit var listView: ListView
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var btnMove: Button
    private lateinit var btnTrash: Button

    private val rowAdapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(position: Int) = if (rows[position] is Row.Head) 0 else 1
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View =
            when (val r = rows[position]) {
                is Row.Head -> ui.headView(r, selected)
                is Row.File -> ui.fileView(r.rec, selected)
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(10))
        }
        root.addView(ui.txt("통화녹음 정리", 24f, INK, true))
        root.addView(ui.txt("v1.0 · 빌드 ${BuildConfig.BUILD_DATE}", 12f, MUTED))

        val bar1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, ui.dp(10), 0, ui.dp(4))
        }
        bar1.addView(ui.btn("새로 검색", TEAL) { checkPermAndScan() }, ui.weight())
        bar1.addView(ui.btn("전체 선택", SLATE) { selectAll(true) }, ui.weight())
        bar1.addView(ui.btn("전체 해제", SLATE) { selectAll(false) }, ui.weight())
        root.addView(bar1)

        val only = CheckBox(this).apply {
            text = "통화 녹음 후보만 보기 (이름/폴더에 통화·녹음 등 포함)"
            isChecked = true
            textSize = 13f
            setOnCheckedChangeListener { _, v -> callOnly = v; rebuild() }
        }
        root.addView(only)

        status = ui.txt("", 13f, MUTED)
        root.addView(status)

        listView = ListView(this).apply {
            adapter = rowAdapter
            divider = null
            setOnItemClickListener { _, _, pos, _ -> onRowClick(pos) }
        }
        root.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        info = ui.txt("", 13f, INK, true)
        info.setPadding(0, ui.dp(8), 0, ui.dp(4))
        root.addView(info)

        val bar2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnMove = ui.btn("그룹별 폴더로 이동", TEAL) { startMove() }
        btnTrash = ui.btn("휴지통으로", DANGER) { startTrash() }
        bar2.addView(btnMove, ui.weight())
        bar2.addView(btnTrash, ui.weight())
        root.addView(bar2)

        setContentView(root)
        updateBar()
        checkPermAndScan()
    }

    private fun perm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun checkPermAndScan() {
        if (checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED) scan()
        else requestPermissions(arrayOf(perm()), RC_PERM)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == RC_PERM && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) {
            scan()
        } else {
            status.text = "오디오 파일 접근 권한이 필요합니다. 새로 검색을 눌러 허용해 주세요."
        }
    }

    private fun scan() {
        status.text = "검색 중..."
        thread {
            val out = ArrayList<Rec>()
            try {
                val proj = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.RELATIVE_PATH,
                    MediaStore.Audio.Media.SIZE,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.DATE_MODIFIED
                )
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, null, null,
                    MediaStore.Audio.Media.DATE_MODIFIED + " DESC"
                )?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                    val iPath = c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)
                    val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                    val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val iDate = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                    while (c.moveToNext()) {
                        val name = c.getString(iName) ?: continue
                        val path = c.getString(iPath) ?: ""
                        val hay = (name + " " + path).lowercase(Locale.ROOT)
                        out.add(
                            Rec(
                                uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(iId)),
                                name = name, path = path,
                                size = c.getLong(iSize), durMs = c.getLong(iDur), date = c.getLong(iDate),
                                group = Util.groupKey(name),
                                call = Util.KEYWORDS.any { hay.contains(it) }
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("검색 오류: ${e.message}") }
            }
            runOnUiThread { recs = out; rebuild() }
        }
    }

    private fun rebuild() {
        val vis = recs.filter { !callOnly || it.call }
        val groups = vis.groupBy { it.group }.entries
            .sortedWith(compareByDescending<Map.Entry<String, List<Rec>>> { it.value.size }.thenBy { it.key })
        rows.clear()
        for ((g, items) in groups) {
            val sorted = items.sortedByDescending { it.date }
            rows.add(Row.Head(g, sorted))
            sorted.forEach { rows.add(Row.File(it)) }
        }
        selected.retainAll(vis.map { it.uri }.toSet())
        rowAdapter.notifyDataSetChanged()
        status.text = "${vis.size}개 파일 · ${groups.size}개 그룹 (전체 오디오 ${recs.size}개)"
        updateBar()
    }

    private fun onRowClick(pos: Int) {
        when (val r = rows[pos]) {
            is Row.Head -> {
                val all = r.items.all { it.uri in selected }
                if (all) r.items.forEach { selected.remove(it.uri) } else r.items.forEach { selected.add(it.uri) }
            }
            is Row.File -> {
                if (!selected.remove(r.rec.uri)) selected.add(r.rec.uri)
            }
        }
        rowAdapter.notifyDataSetChanged()
        updateBar()
    }

    private fun selectAll(on: Boolean) {
        selected.clear()
        if (on) rows.forEach { if (it is Row.File) selected.add(it.rec.uri) }
        rowAdapter.notifyDataSetChanged()
        updateBar()
    }

    private fun selectedRecs() = recs.filter { it.uri in selected }

    private fun updateBar() {
        val sel = selectedRecs()
        info.text = if (sel.isEmpty()) "선택한 파일 없음" else "선택 ${sel.size}개 · ${Util.fmtBytes(sel.sumOf { it.size })}"
        val on = sel.isNotEmpty()
        for (b in listOf(btnMove, btnTrash)) { b.isEnabled = on; b.alpha = if (on) 1f else 0.4f }
    }

    private fun startMove() {
        val sel = selectedRecs()
        if (sel.isEmpty()) return
        val et = EditText(this).apply { setText("통화녹음분리"); setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("이동할 폴더 이름")
            .setMessage("Music/<폴더>/<그룹명>/ 으로 ${sel.size}개 파일을 이동합니다.")
            .setView(et)
            .setPositiveButton("이동") { _, _ ->
                pendingMove = sel
                pendingBase = Util.safe(et.text.toString(), "통화녹음분리")
                requestSystem(RC_WRITE, MediaStore.createWriteRequest(contentResolver, sel.map { it.uri }))
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun startTrash() {
        val sel = selectedRecs()
        if (sel.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("휴지통으로 이동")
            .setMessage("${sel.size}개 파일(${Util.fmtBytes(sel.sumOf { it.size })})을 휴지통으로 보냅니다. 시스템 휴지통에서 약 30일간 복구할 수 있습니다.")
            .setPositiveButton("휴지통으로") { _, _ ->
                requestSystem(RC_TRASH, MediaStore.createTrashRequest(contentResolver, sel.map { it.uri }, true))
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun requestSystem(code: Int, pi: PendingIntent) {
        try {
            startIntentSenderForResult(pi.intentSender, code, null, 0, 0, 0)
        } catch (e: Exception) {
            toast("요청 실패: ${e.message}")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != RC_WRITE && requestCode != RC_TRASH) return
        if (resultCode != RESULT_OK) { toast("취소되었습니다"); return }
        if (requestCode == RC_WRITE) {
            doMove()
        } else {
            toast("휴지통으로 이동했습니다")
            selected.clear()
            scan()
        }
    }

    private fun doMove() {
        val targets = pendingMove
        val base = pendingBase
        thread {
            var ok = 0
            var fail = 0
            for (r in targets) {
                try {
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/$base/${Util.safe(r.group, "기타")}/")
                    }
                    if (contentResolver.update(r.uri, cv, null, null) > 0) ok++ else fail++
                } catch (e: Exception) {
                    fail++
                }
            }
            runOnUiThread {
                toast("이동 완료 ${ok}개, 실패 ${fail}개")
                selected.clear()
                scan()
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
