package com.callsort

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity() {

    companion object {
        const val RC_PERM = 1
        const val RC_WRITE = 2
        const val RC_TRASH = 3
        const val BATCH = 1000
    }

    private val ui by lazy { Ui(this) }

    private var recs: List<Rec> = emptyList()
    private val rows = ArrayList<Row>()
    private val selected = HashSet<Uri>()
    private var callOnly = true
    private var query = ""
    private var openGroup: String? = null

    private val queue = ArrayDeque<List<Rec>>()
    private var pendingAction = 0
    private var pendingBase = ""
    private var okCount = 0
    private var failCount = 0

    private lateinit var listView: ListView
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var searchBox: EditText
    private lateinit var onlyBox: CheckBox
    private lateinit var barGroup: LinearLayout
    private lateinit var barDetail: LinearLayout
    private lateinit var bottomGroup: LinearLayout
    private lateinit var bottomDetail: LinearLayout
    private lateinit var btnMove: Button
    private lateinit var btnTrash: Button
    private lateinit var btnPlay: Button

    private val rowAdapter = object : BaseAdapter() {
        override fun getCount() = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getViewTypeCount() = 2
        override fun getItemViewType(position: Int) = if (rows[position] is Row.Group) 0 else 1
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View =
            when (val r = rows[position]) {
                is Row.Group -> ui.groupView(r)
                is Row.File -> ui.fileView(r.rec, selected)
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(10))
        }
        root.addView(ui.txt("통화녹음 정리", 24f, INK, true))
        root.addView(ui.txt("v2.0 · 빌드 ${BuildConfig.BUILD_DATE}", 12f, MUTED))

        barGroup = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, ui.dp(10), 0, ui.dp(4))
        }
        barGroup.addView(ui.btn("새로 검색", TEAL) { checkPermAndScan() }, ui.weight())
        root.addView(barGroup)

        barDetail = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, ui.dp(10), 0, ui.dp(4))
        }
        barDetail.addView(ui.btn("← 이름 목록", SLATE) { goBack() }, ui.weight())
        barDetail.addView(ui.btn("전체 선택", SLATE) { selectAll(true) }, ui.weight())
        barDetail.addView(ui.btn("전체 해제", SLATE) { selectAll(false) }, ui.weight())
        root.addView(barDetail)

        searchBox = EditText(this).apply {
            hint = "이름·파일명·폴더 검색"
            setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s?.toString() ?: ""; rebuild() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        root.addView(searchBox)

        onlyBox = CheckBox(this).apply {
            text = "통화 녹음 후보만 보기 (이름/폴더에 통화·녹음 등 포함)"
            isChecked = true
            textSize = 13f
            setOnCheckedChangeListener { _, v -> callOnly = v; rebuild() }
        }
        root.addView(onlyBox)

        status = ui.txt("", 13f, MUTED)
        root.addView(status)

        listView = ListView(this).apply {
            adapter = rowAdapter
            divider = null
            setOnItemClickListener { _, _, pos, _ -> onRowClick(pos) }
        }
        root.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        info = ui.txt("", 13f, INK, true)
        info.setPadding(0, ui.dp(8), 0, ui.dp(4))
        root.addView(info)

        bottomGroup = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottomGroup.addView(ui.btn("이름별 자동 분류 (전체)", TEAL) { startAutoSort() }, ui.weight())
        root.addView(bottomGroup)

        bottomDetail = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btnPlay = ui.btn("선택 파일 재생", SLATE) { playSelected() }
        btnMove = ui.btn("이 이름 폴더로 이동", TEAL) { startMoveSelected() }
        btnTrash = ui.btn("휴지통으로", DANGER) { startTrash() }
        bottomDetail.addView(btnPlay, ui.weight())
        bottomDetail.addView(btnMove, ui.weight())
        bottomDetail.addView(btnTrash, ui.weight())
        root.addView(bottomDetail)

        setContentView(root)
        applyMode()
        updateBar()
        checkPermAndScan()
    }

    private fun applyMode() {
        val detail = openGroup != null
        barGroup.visibility = if (detail) View.GONE else View.VISIBLE
        barDetail.visibility = if (detail) View.VISIBLE else View.GONE
        searchBox.visibility = View.VISIBLE
        onlyBox.visibility = if (detail) View.GONE else View.VISIBLE
        bottomGroup.visibility = if (detail) View.GONE else View.VISIBLE
        bottomDetail.visibility = if (detail) View.VISIBLE else View.GONE
        info.visibility = if (detail) View.VISIBLE else View.GONE
    }

    private fun goBack() {
        openGroup = null
        selected.clear()
        applyMode()
        rebuild()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (openGroup != null) goBack() else super.onBackPressed()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchBox.windowToken, 0)
        searchBox.clearFocus()
    }

    private fun perm() =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun checkPermAndScan() {
        if (checkSelfPermission(perm()) == PackageManager.PERMISSION_GRANTED) scan()
        else requestPermissions(arrayOf(perm()), RC_PERM)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == RC_PERM && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) {
            scan()
        } else {
            status.text = "오디오 파일 접근 권한이 필요합니다. 새로 검색을 눌러 허용해 주세요."
        }
    }

    private fun scan() {
        status.text = "검색 중..."
        thread {
            val out = ArrayList<Rec>()
            try {
                val proj = arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.RELATIVE_PATH,
                    MediaStore.Audio.Media.SIZE,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.DATE_MODIFIED
                )
                contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, null, null,
                    MediaStore.Audio.Media.DATE_MODIFIED + " DESC"
                )?.use { c ->
                    val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                    val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                    val iPath = c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)
                    val iSize = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                    val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val iDate = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                    while (c.moveToNext()) {
                        val name = c.getString(iName) ?: continue
                        val path = c.getString(iPath) ?: ""
                        val hay = (name + " " + path).lowercase(Locale.ROOT)
                        out.add(
                            Rec(
                                uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(iId)),
                                name = name, path = path,
                                size = c.getLong(iSize), durMs = c.getLong(iDur), date = c.getLong(iDate),
                                group = Util.groupKey(name),
                                call = Util.KEYWORDS.any { hay.contains(it) }
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("검색 오류: ${e.message}") }
            }
            runOnUiThread { recs = out; rebuild() }
        }
    }

    private fun rebuild() {
        val vis = recs.filter { !callOnly || it.call }
        rows.clear()
        val g = openGroup
        if (g == null) {
            val q = query.trim().lowercase(Locale.ROOT)
            val groups = vis.groupBy { it.group }.entries
                .filter { q.isEmpty() || it.key.lowercase(Locale.ROOT).contains(q) }
                .sortedWith(compareByDescending<Map.Entry<String, List<Rec>>> { it.value.size }.thenBy { it.key })
            for ((name, items) in groups) rows.add(Row.Group(name, items))
            status.text = "${groups.size}개 이름 · ${groups.sumOf { it.value.size }}개 파일 (전체 오디오 ${recs.size}개)"
        } else {
            val q = query.trim().lowercase(Locale.ROOT)
            val items = vis.filter {
                it.group == g && (q.isEmpty() || it.name.lowercase(Locale.ROOT).contains(q) ||
                    it.path.lowercase(Locale.ROOT).contains(q) || it.group.lowercase(Locale.ROOT).contains(q))
            }.sortedByDescending { it.date }
            if (vis.none { it.group == g }) {
                openGroup = null
                applyMode()
                rebuild()
                return
            }
            items.forEach { rows.add(Row.File(it)) }
            selected.retainAll(items.map { it.uri }.toSet())
            status.text = "$g · ${items.size}개 파일 · 전체 ${vis.size}개 중 (눌러서 선택)"
        }
        rowAdapter.notifyDataSetChanged()
        updateBar()
    }

    private fun onRowClick(pos: Int) {
        when (val r = rows[pos]) {
            is Row.Group -> {
                hideKeyboard()
                openGroup = r.group
                selected.clear()
                applyMode()
                rebuild()
                listView.setSelection(0)
            }
            is Row.File -> {
                if (!selected.remove(r.rec.uri)) selected.add(r.rec.uri)
                rowAdapter.notifyDataSetChanged()
                updateBar()
            }
        }
    }

    private fun selectAll(on: Boolean) {
        selected.clear()
        if (on) rows.forEach { if (it is Row.File) selected.add(it.rec.uri) }
        rowAdapter.notifyDataSetChanged()
        updateBar()
    }

    private fun selectedRecs() = recs.filter { it.uri in selected }

    private fun updateBar() {
        val sel = selectedRecs()
        info.text = if (sel.isEmpty()) "선택한 파일 없음" else "선택 ${sel.size}개 · ${Util.fmtBytes(sel.sumOf { it.size })}"
        val on = sel.isNotEmpty()
        for (b in listOf(btnPlay, btnMove, btnTrash)) { b.isEnabled = on; b.alpha = if (on) 1f else 0.4f }
    }

    private fun playSelected() {
        val item = selectedRecs().firstOrNull()
        if (item == null) { toast("재생할 파일을 선택해 주세요"); return }
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(item.uri, "audio/*")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "녹음 파일 재생"))
        } catch (e: Exception) { toast("재생 앱을 찾을 수 없습니다: ${e.message}") }
    }

    // 이 이름에서 선택한 파일만 Music/<폴더>/<이름>/ 으로 이동
    private fun startMoveSelected() {
        val sel = selectedRecs()
        if (sel.isEmpty()) return
        val et = EditText(this).apply { setText("통화녹음분리"); setSingleLine() }
        AlertDialog.Builder(this)
            .setTitle("이동할 폴더 이름")
            .setMessage("Music/<폴더>/<이름>/ 으로 선택한 ${sel.size}개 파일을 이동합니다.")
            .setView(et)
            .setPositiveButton("이동") { _, _ ->
                startBatches(RC_WRITE, sel, Util.safe(et.text.toString(), "통화녹음분리"))
            }
            .setNegativeButton("취소", null)
            .show()
    }

    // 선택한 파일만 휴지통으로
    private fun startTrash() {
        val sel = selectedRecs()
        if (sel.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle("휴지통으로 이동")
            .setMessage("선택한 ${sel.size}개 파일(${Util.fmtBytes(sel.sumOf { it.size })})을 휴지통으로 보냅니다. 시스템 휴지통에서 약 30일간 복구할 수 있습니다.")
            .setPositiveButton("휴지통으로") { _, _ -> startBatches(RC_TRASH, sel, "") }
            .setNegativeButton("취소", null)
            .show()
    }

    // 전체를 이름별 폴더로 자동 분류 (파일이 N개 이상인 이름만)
    private fun startAutoSort() {
        val vis = recs.filter { (!callOnly || it.call) && it.group != "(이름 없음)" }
        if (vis.isEmpty()) { toast("분류할 파일이 없습니다"); return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ui.dp(20), ui.dp(8), ui.dp(20), 0)
        }
        val etBase = EditText(this).apply { setText("통화녹음분리"); setSingleLine() }
        val etMin = EditText(this).apply {
            setText("2"); setSingleLine(); inputType = InputType.TYPE_CLASS_NUMBER
        }
        box.addView(ui.txt("폴더 이름", 12f, MUTED))
        box.addView(etBase)
        box.addView(ui.txt("파일이 이 개수 이상인 이름만 분류", 12f, MUTED))
        box.addView(etMin)
        AlertDialog.Builder(this)
            .setTitle("이름별 자동 분류")
            .setMessage("Music/<폴더>/<이름>/ 으로 이동합니다. 파일이 많으면 확인 창이 여러 번 뜹니다.")
            .setView(box)
            .setPositiveButton("분류") { _, _ ->
                val min = (etMin.text.toString().toIntOrNull() ?: 2).coerceAtLeast(1)
                val counts = vis.groupingBy { it.group }.eachCount()
                val targets = vis.filter { (counts[it.group] ?: 0) >= min }
                startBatches(RC_WRITE, targets, Util.safe(etBase.text.toString(), "통화녹음분리"))
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun startBatches(action: Int, list: List<Rec>, base: String) {
        if (list.isEmpty()) { toast("대상 파일이 없습니다"); return }
        pendingAction = action
        pendingBase = base
        okCount = 0
        failCount = 0
        queue.clear()
        list.chunked(BATCH).forEach { queue.addLast(it) }
        processNext()
    }

    private fun processNext() {
        val batch = queue.firstOrNull()
        if (batch == null) { finishAll(); return }
        val uris = batch.map { it.uri }
        val pi = if (pendingAction == RC_WRITE) {
            MediaStore.createWriteRequest(contentResolver, uris)
        } else {
            MediaStore.createTrashRequest(contentResolver, uris, true)
        }
        requestSystem(pendingAction, pi)
    }

    private fun finishAll() {
        if (pendingAction == RC_WRITE) toast("이동 완료 ${okCount}개, 실패 ${failCount}개")
        else toast("휴지통으로 ${okCount}개 이동했습니다")
        selected.clear()
        scan()
    }

    private fun requestSystem(code: Int, pi: PendingIntent) {
        try {
            startIntentSenderForResult(pi.intentSender, code, null, 0, 0, 0)
        } catch (e: Exception) {
            toast("요청 실패: ${e.message}")
            queue.clear()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != RC_WRITE && requestCode != RC_TRASH) return
        if (resultCode != RESULT_OK) {
            toast("취소되었습니다 (처리된 파일 ${okCount}개)")
            queue.clear()
            selected.clear()
            scan()
            return
        }
        val batch = queue.removeFirstOrNull() ?: return
        if (requestCode == RC_WRITE) {
            moveBatch(batch)
        } else {
            okCount += batch.size
            processNext()
        }
    }

    private fun moveBatch(batch: List<Rec>) {
        val base = pendingBase
        thread {
            var ok = 0
            var fail = 0
            for (r in batch) {
                try {
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/$base/${Util.safe(r.group, "기타")}/")
                    }
                    if (contentResolver.update(r.uri, cv, null, null) > 0) ok++ else fail++
                } catch (e: Exception) {
                    fail++
                }
            }
            runOnUiThread {
                okCount += ok
                failCount += fail
                processNext()
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
