package com.callsort

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView

val BG = 0xFFF4F7F8.toInt()
val INK = 0xFF1F2D3A.toInt()
val MUTED = 0xFF6B7C88.toInt()
val TEAL = 0xFF0F7C86.toInt()
val SLATE = 0xFF33475B.toInt()
val DANGER = 0xFFB3392F.toInt()
val HEAD_BG = 0xFFDCEBEE.toInt()
val SEL_BG = 0xFFE8F5F6.toInt()

class Ui(private val ctx: Context) {
    private val d = ctx.resources.displayMetrics.density

    fun dp(v: Int) = (v * d).toInt()

    fun rect(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = r * d }

    fun txt(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    fun btn(label: String, color: Int, onClick: () -> Unit) = Button(ctx).apply {
        text = label; setTextColor(0xFFFFFFFF.toInt()); textSize = 14f; isAllCaps = false
        background = rect(color, 10)
        setOnClickListener { onClick() }
    }

    fun cb(checked: Boolean) = CheckBox(ctx).apply {
        isChecked = checked; isClickable = false; isFocusable = false
    }

    fun weight() = LinearLayout.LayoutParams(0, dp(44), 1f).apply { setMargins(dp(3), 0, dp(3), 0) }

    fun headView(h: Row.Head, selected: Set<Uri>): View {
        val all = h.items.all { it.uri in selected }
        val inner = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rect(HEAD_BG, 10)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        inner.addView(cb(all))
        val total = h.items.sumOf { it.size }
        val t = txt("${h.group}  ·  ${h.items.size}개 · ${Util.fmtBytes(total)}", 16f, INK, true)
        inner.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(2))
            addView(inner)
        }
    }

    fun fileView(r: Rec, selected: Set<Uri>): View {
        val sel = r.uri in selected
        val l = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(8), dp(6), dp(8))
            if (sel) background = rect(SEL_BG, 8)
        }
        l.addView(cb(sel))
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(txt(r.name, 14f, INK).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.MIDDLE })
        col.addView(txt("${Util.fmtDate(r.date)} · ${Util.fmtDur(r.durMs)} · ${Util.fmtBytes(r.size)}", 12f, MUTED))
        col.addView(txt(r.path, 11f, MUTED).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
        l.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return l
    }
}
