# CallSort PRO 2.1 (참고 프로젝트 기반 개선판)

## 반영한 개선
- 앱 표시 이름을 CallSort PRO로 변경
- 버전 코드/표시를 2 / 2.1로 갱신
- 그룹 목록에서 이름 검색 유지
- 상세 파일 목록에서도 파일명/폴더/그룹 검색 가능
- 선택한 녹음 파일을 Android 기본 오디오 앱으로 재생 요청
- 기존 MediaStore 검색, 그룹화, 선택, 이동, 휴지통 기능 유지

## 중요한 제한
- 제공된 callsort_project.zip 기반 참고용 개선판이며 실제 설치된 최신 앱 원본인지 확인되지 않았습니다.
- 자동 분류는 기존 파일명 규칙 기반입니다. 연락처 연동은 아직 추가하지 않았습니다.
- 재생은 외부 Android 오디오 앱으로 위임합니다.
- 파일 이동/휴지통 승인 플로우는 실제 기기에서 테스트해야 합니다.

## 빌드
Android Studio에서 프로젝트를 열고 Gradle Sync 후 :app:assembleDebug 실행.
필요 환경: JDK 17, Android SDK 34, Android Gradle Plugin 8.5.2.
